// JS
import './js/'

// SCSS
import './scss/style.scss'

// CSS (example)
// import './css/main.css'
